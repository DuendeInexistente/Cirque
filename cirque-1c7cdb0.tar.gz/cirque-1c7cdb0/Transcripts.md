### 04 - 13

>**Me**: What is your name?
>
>**??**: This unit's operative classification is beta pink-03.
>
>**M**: Can I call you pink?
>
>**Pink**: This unit lacks the ability to disagree.
>
>**M**: I'll take that as a yes.
>
>**P**: This unit lacks the ability to disagree.
>
>**M**: Are there other units?
>
>**P**: Six units, including this unit, were deployed by Princess Twilight Sparkle to retrieve the Equestrian citizen Lettuce Leaf.
>
>**M**: Princess? (It didn't answer) Twilight Sparkle is not a princess.
>
>**P**: Princess Twilight Sparkle is a princess.
>
>**M**: Let's say I believe that. She sent you for this Lettuce Leaf?
>
>**P**: That is this unit's mission statement. Are you the citizen Lettuce Leaf?
>
>**M**: Again, no. Did he disappear too?
>
>**P**: On the morning of the fifth moon his house was found missing, and Princess Twilight Sparkle was issued to assist in his safe return to Equestria.
>
>**M**: But we are on the third moon.
>
>**P**: Calendars adjusted previsorily. This unit will now seek Lettuce Leaf.
>
>**M**: Wait! Can't you help me?
>
>**P**: This unit's mission statement is to seek and assist Lettuce Leaf.
>
>**M**: I can help you search him.
>
>**P**: This unit is equipped to find citizen Lettuce Leaf, and all other stars, on it's own. Are you too an Equestrian Citizen?
>
>**M**: Yes! I am Creeking Meadow!
>
>**P**: Citizen Lettuce Leaf will be informed of Citizen Creaking Meadow's last known position. If unable to find Citizen Lettuce Leaf, this Star will hibernate within the highest spot of this city and search again in regular intervals.
>
>(It flew off the window after this)

#### 3 - 18

>(Creaking asked me to transcribe discretely for her, since our "dear" hostess doesn't seem like she'd like to know I am doing it.)
>
>
>**Cr**: I still don't know what do you mean by “Saving” us.
>
>**Ch**: Adapting. Helping you be able to survive in a environment you crearly werent made for, like my own subjects werent.
>
>**Me**: Your subjects werent adaptable enough on their own?
>
>**Ch**: No, as a mater of fact. They werent.
>
>**Cr**: I somehow find that hard to believe.
>
>**Ch**: You somehow seem to think your belief maters.
>
>**Cr**: Did your subjects believe?
>
>**Ch**: My results were proof enough.
>
>**Cr**: You mutilated them.
>
>**Ch**: Adaptation is never easy, little kid. I-- You of all people should know that. Will you keep abusing my patience after I let you into my household, or can I eat in peace now?

