Onwards and upwards! The very stars cry at our insult, their self indulgence nothing but the seeds of their thwarting! Destiny and oblivion reach for us like crashing waves and I say, let them! Let them think we will fall under their weight, let them rue the outcry they know to expect in the back of their minds! Let them cry in rage when we spit blood on their eyes! Let destiny crackle and fate tremble, let us strike them with the most sinful offences before they strike us down, so that we chortle our hubris on the face of Nemesis, for such is the Equestrian soul.

To trust an unicorn is to be a fool, and I am no fool, but curses! Let the earth swallow them, for they are my only hope of ever returning home! Ha! Is this the Nemes, is this the supposed punishment!? Fool that it is, for these unicorns share my spite, share my drive to spit on destiny, to curse the stars! Their danger is great, but their mettle commendable! Call me a fool, and I may be, for the same machine that brought us across the ether will carry us back, so that our own stardom, our own gods, may see that our insult knows not only theirs but these alien skies as well!

Onwards and upwards, Onerai!

&lt;div align="center"&gt;~•~&lt;/div&gt;

With the very same world that our gods gave us we challenge them, did they not see the irony of it? Did they not burst in laugher at it? Fa, let them! We have collected many artifacts from begone ages so that we may strike the heavens. And strike we will! With the Phoenix on our tails, we shall find tools of the civilizations it has destroyed! We shall spit others' blood onto its eyes, and see it sizzle with the fire of their and its fury.

&lt;div align="center"&gt;~•~&lt;/div&gt;

The Phoenix has recruited copper soldiers onto its ranks. Pha! They have no passion, no life! This is not a combat of wills, but an affront to mine. I tried to parlay with one, and it did not have the decency to answer.

Is this my true Nemes? If it is the gods have truly grown insidious. Ha! Do they not understand that it is because of me? Does it not embitten their hearts to know that they had to improve because of me?

&lt;div align="center"&gt;~•~&lt;/div&gt;

Pha! I tried to parlay with one of the coppers and it did not answer. It lacked a mouth, even! It moved like an animal, and it was not until I removed the broken pieces of its glass eye that it stopped attacking.

&lt;div align="center"&gt;~•~&lt;/div&gt;

I have collected a reliquary from the frozen wastes, filled with glowing white dust. The Phoenix has not followed me here, and I can see why: The moon draws ever closer and lower.

Onwards, Onerai!

&lt;div align="center"&gt;~•~&lt;/div&gt;

Ha! Entangled in the strands of fate, we find a new life in death! We curse the stars and challenge them, and by our hysteric screaming find, nay, create a new lease in life! Ha! Onerai, what do you think of me?! Can you laugh with me, can you see I now understand the clarity in your whimsy? Can you see how I have found an entire new world just do that it can also be cursed, so that its gods can also hear our rimbombant laugh as we find life in death?

Onwards and upwards, ever forwards! For I know in my heart you hear my laughter, Onerai!

&lt;div align="center"&gt;~•~&lt;/div&gt;

Shout with your \*'Vota\* once more, Onerai, for we have made it! The unicorns finished the contraption, made the machine so that we may again find home, and our own gods know of our insult!

This journal will be the proof that it takes for the academy to acknowledge us, and the unicorns have embedded it with magics to make it timeless. Ha! Even time itself surrenders to our mania!

Being barricated means nothing, nor being surrounded! The gods' fury only makes us greater, grander, makes our escape a last challenge to overcome! Let them, let them attack us, surround us, kill us, so that the insult of our escape is ever greater! For it's with the sun's own energy that we power our escape!

Onwards and ever forward, Onerai! Past the veil of the ether, past the veil of our worlds!

